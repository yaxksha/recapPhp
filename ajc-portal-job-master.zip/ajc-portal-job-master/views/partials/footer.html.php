<footer>
    @copyright 2000
</footer>
</body>
</html>